document.addEventListener("DOMContentLoaded", () => {
    console.log("JavaScript is working");
    console.log("Survey script loaded successfully!");

    let questionCounter = 1; // Tracks the number of questions added

    // Function to add a new question dynamically
    const addQuestion = () => {
        questionCounter++; // Increment question counter
        console.log(`Creating new question number: ${questionCounter}`);

        const questionsContainer = document.getElementById("questions-container");
        if (questionsContainer) {
            const newQuestion = document.createElement("div");
            newQuestion.className = "question";
            newQuestion.id = `question_${questionCounter}`;
            newQuestion.innerHTML = `
                <button type="button" class="close-question-btn" aria-label="Close Question">&times;</button>
                <label for="question_${questionCounter}">Question ${questionCounter}:</label>
                <input type="text" id="question_${questionCounter}" name="questions[${questionCounter}][text]" placeholder="Enter your question" required>
                <label for="type_${questionCounter}">Type:</label>
                <select id="type_${questionCounter}" name="questions[${questionCounter}][type]" required>
                    <option value="radio">Radio Button (Single Choice)</option>
                </select>
                <div id="options-container-${questionCounter}" class="options-container">
                    <label>Options:</label>
                    <div class="option-wrapper">
                        <input type="text" name="questions[${questionCounter}][options][]" placeholder="Option 1" required>
                    </div>
                    <div class="option-wrapper">
                        <input type="text" name="questions[${questionCounter}][options][]" placeholder="Option 2" required>
                    </div>
                    <button type="button" class="add-option-btn btn btn-success" data-question-id="${questionCounter}">Add Option</button>
                </div>
            `;
            questionsContainer.appendChild(newQuestion);

            attachAddOptionListener(newQuestion);
            console.log(`New question added: Question ${questionCounter}`);
        } else {
            console.error("Questions container not found");
        }
    };

    // Attach add-option functionality to the newly added question
    const attachAddOptionListener = (questionElement) => {
        const addOptionBtn = questionElement.querySelector(".add-option-btn");
        addOptionBtn.addEventListener("click", () => {
            const questionId = addOptionBtn.dataset.questionId;
            const optionsContainer = document.getElementById(`options-container-${questionId}`);
            if (optionsContainer) {
                const optionCount = optionsContainer.querySelectorAll(".option-wrapper").length + 1;
                if (optionCount > 5) {
                    alert("You can only add up to 5 options per question.");
                    return;
                }

                const optionWrapper = document.createElement("div");
                optionWrapper.className = "option-wrapper";
                optionWrapper.innerHTML = `
                    <input type="text" name="questions[${questionId}][options][]" placeholder="Option ${optionCount}" required>
                `;
                optionsContainer.insertBefore(optionWrapper, addOptionBtn);
                console.log(`Option added successfully to question ID: ${questionId}`);
            } else {
                console.error(`Options container not found for question ID: ${questionId}`);
            }
        });
    };

    const addQuestionBtn = document.getElementById("add-question-btn");
    if (addQuestionBtn) {
        addQuestionBtn.addEventListener("click", addQuestion);
    } else {
        console.error("Add Question button not found");
    }

    // Attach listeners to preloaded questions
    document.querySelectorAll(".question").forEach((question) => {
        attachAddOptionListener(question);
    });

    // Remove question functionality
    document.addEventListener("click", (event) => {
        if (event.target.classList.contains("close-question-btn")) {
            const questionPanel = event.target.closest(".question");
            if (questionPanel) {
                questionPanel.remove();
                console.log("Question removed successfully");
            }
        }
    });

    console.log("Survey script initialized successfully!");
});
